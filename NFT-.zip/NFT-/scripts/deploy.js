async function main() {
  const MyNFT = await ethers.getContractFactory("MyNFT");

  // Start deployment, returning a promise that resolves to a contract object
  const myNFT = await MyNFT.deploy();
  console.log("Contract deployed to address:", myNFT.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
//0x0A8A09589986B78bC94d36c560362e82aA4Ab2AE
//0x0A8A09589986B78bC94d36c560362e82aA4Ab2AE
//0xf0768b8993a7E0E2b4dCa74C523e30C57BF9BAdb
